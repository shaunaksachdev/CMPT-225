#ifndef AVLTREE_H
#define AVLTREE_H

#include <vector>
#include <stdexcept>
#include <algorithm>

template <typename K, typename V>
class AVLTreeNode {
public:
    K key;
    V value;
    AVLTreeNode* left;
    AVLTreeNode* right;
    AVLTreeNode* parent;
    unsigned int height;

    // constructor
    AVLTreeNode(const K& k, const V& v) : key(k), value(v), left(nullptr), right(nullptr), parent(nullptr), height(0) {}
};

template <typename K, typename V>
class AVLTree {
private:
    AVLTreeNode<K, V>* root;
    unsigned int treeSize;

    // helper methods
    void deleteTree(AVLTreeNode<K, V>* node);
    AVLTreeNode<K, V>* copyTree(const AVLTreeNode<K, V>* node);
    unsigned int getHeight(AVLTreeNode<K, V>* node) const;
    void updateHeight(AVLTreeNode<K, V>* node);
    int getBalanceFactor(AVLTreeNode<K, V>* node) const;
    AVLTreeNode<K, V>* rotateRight(AVLTreeNode<K, V>* y);
    AVLTreeNode<K, V>* rotateLeft(AVLTreeNode<K, V>* x);
    AVLTreeNode<K, V>* balance(AVLTreeNode<K, V>* node);
    AVLTreeNode<K, V>* findMin(AVLTreeNode<K, V>* node) const;
    AVLTreeNode<K, V>* insertHelper(AVLTreeNode<K, V>* node, const K& key, const V& value, bool& inserted);
    AVLTreeNode<K, V>* removeHelper(AVLTreeNode<K, V>* node, const K& key, bool& removed);
    void inOrderTraversal(AVLTreeNode<K, V>* node, std::vector<K>& keyList) const;
    void inOrderTraversalValues(AVLTreeNode<K, V>* node, std::vector<V>& valueList) const;

public:
    // constructor
    AVLTree() : root(nullptr), treeSize(0) {}

    // copy constructor
    AVLTree(const AVLTree<K, V>& other);

    // assignment operator
    AVLTree<K, V>& operator=(const AVLTree<K, V>& other);

    // destructor
    ~AVLTree();

    // insert method
    bool insert(const K& key, const V& value);

    // remove method
    bool remove(const K& key);

    // search method
    V search(const K& key) const;

    // values method
    std::vector<V> values() const;

    // keys method
    std::vector<K> keys() const;

    // size method
    unsigned int size() const;

    AVLTreeNode<K, V>* getRoot() const { return root; }
};

// copy constructor
template <typename K, typename V>
AVLTree<K, V>::AVLTree(const AVLTree<K, V>& other) : root(nullptr), treeSize(0) {
    if (other.root != nullptr) {
        root = copyTree(other.root);
        treeSize = other.treeSize;
    }
}

// assignment operator
template <typename K, typename V>
AVLTree<K, V>& AVLTree<K, V>::operator=(const AVLTree<K, V>& other) {
    if (this != &other) {  
        deleteTree(root);
        root = nullptr;
        treeSize = 0;

        if (other.root != nullptr) {
            root = copyTree(other.root);
            treeSize = other.treeSize;
        }
    }
    return *this;
}

// destructor
template <typename K, typename V>
AVLTree<K, V>::~AVLTree() {
    deleteTree(root);
}

template <typename K, typename V>
void AVLTree<K, V>::deleteTree(AVLTreeNode<K, V>* node) {
    if (node != nullptr) {
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }
}

template <typename K, typename V>
AVLTreeNode<K, V>* AVLTree<K, V>::copyTree(const AVLTreeNode<K, V>* node) {
    if (node == nullptr) {
        return nullptr;
    }
    
    AVLTreeNode<K, V>* newNode = new AVLTreeNode<K, V>(node->key, node->value);
    newNode->height = node->height;
    
    newNode->left = copyTree(node->left);
    if (newNode->left != nullptr) {
        newNode->left->parent = newNode;
    }
    
    newNode->right = copyTree(node->right);
    if (newNode->right != nullptr) {
        newNode->right->parent = newNode;
    }
    
    return newNode;
}

// to get the height of a node
template <typename K, typename V>
unsigned int AVLTree<K, V>::getHeight(AVLTreeNode<K, V>* node) const {
    return (node == nullptr) ? 0 : node->height;
}

// to update the height of a node
template <typename K, typename V>
void AVLTree<K, V>::updateHeight(AVLTreeNode<K, V>* node) {
    if (node != nullptr) {
        node->height = 1 + std::max(getHeight(node->left), getHeight(node->right));
    }
}

// to get the balance factor of a node
template <typename K, typename V>
int AVLTree<K, V>::getBalanceFactor(AVLTreeNode<K, V>* node) const {
    return (node == nullptr) ? 0 : getHeight(node->left) - getHeight(node->right);
}

// right rotation
template <typename K, typename V>
AVLTreeNode<K, V>* AVLTree<K, V>::rotateRight(AVLTreeNode<K, V>* y) {
    AVLTreeNode<K, V>* x = y->left;
    AVLTreeNode<K, V>* T2 = x->right;
    
    x->parent = y->parent;
    if (y->parent != nullptr) {
        if (y->parent->left == y) {
            y->parent->left = x;
        } else {
            y->parent->right = x;
        }
    } else {
        root = x;
    }
    
    x->right = y;
    y->parent = x;
    
    y->left = T2;
    if (T2 != nullptr) {
        T2->parent = y;
    }
    
    updateHeight(y);
    updateHeight(x);
    
    return x;
}

// left rotation
template <typename K, typename V>
AVLTreeNode<K, V>* AVLTree<K, V>::rotateLeft(AVLTreeNode<K, V>* x) {
    AVLTreeNode<K, V>* y = x->right;
    AVLTreeNode<K, V>* T2 = y->left;
    
    y->parent = x->parent;
    if (x->parent != nullptr) {
        if (x->parent->left == x) {
            x->parent->left = y;
        } else {
            x->parent->right = y;
        }
    } else {
        root = y;
    }
    
    y->left = x;
    x->parent = y;
    
    x->right = T2;
    if (T2 != nullptr) {
        T2->parent = x;
    }
    
    updateHeight(x);
    updateHeight(y);
    
    return y;
}
// balance node 
template <typename K, typename V>
AVLTreeNode<K, V>* AVLTree<K, V>::balance(AVLTreeNode<K, V>* node) {
    if (node == nullptr) {
        return nullptr;
    }
    
    updateHeight(node);
    
    int balance = getBalanceFactor(node);
    
    // left heavy
    if (balance > 1) {
        // left-right case
        if (getBalanceFactor(node->left) < 0) {
            node->left = rotateLeft(node->left);
        }
        // left-left case
        return rotateRight(node);
    }
    
    // tight heavy
    if (balance < -1) {
        // right-left case
        if (getBalanceFactor(node->right) > 0) {
            node->right = rotateRight(node->right);
        }
        // right-right case
        return rotateLeft(node);
    }
    
    return node;
}

// finding the minimum value node in the tree
template <typename K, typename V>
AVLTreeNode<K, V>* AVLTree<K, V>::findMin(AVLTreeNode<K, V>* node) const {
    if (node == nullptr) {
        return nullptr;
    }
    
    while (node->left != nullptr) {
        node = node->left;
    }
    
    return node;
}

// inserting helper method
template <typename K, typename V>
AVLTreeNode<K, V>* AVLTree<K, V>::insertHelper(AVLTreeNode<K, V>* node, const K& key, const V& value, bool& inserted) {
    // base case: we've reached a leaf node
    if (node == nullptr) {
        inserted = true;
        treeSize++;
        return new AVLTreeNode<K, V>(key, value);
    }
    
    // BST insertion
    if (key < node->key) {
        node->left = insertHelper(node->left, key, value, inserted);
        if (node->left != nullptr) {
            node->left->parent = node;
        }
    } else if (key > node->key) {
        node->right = insertHelper(node->right, key, value, inserted);
        if (node->right != nullptr) {
            node->right->parent = node;
        }
    } else {
        // key already exists so no insertion needed
        inserted = false;
        return node;
    }
    
    // balance the tree after insertion
    return balance(node);
}

// removing helper method
template <typename K, typename V>
AVLTreeNode<K, V>* AVLTree<K, V>::removeHelper(AVLTreeNode<K, V>* node, const K& key, bool& removed) {
    if (node == nullptr) {
        removed = false;
        return nullptr;
    }
    
    //BST deletion
    if (key < node->key) {
        node->left = removeHelper(node->left, key, removed);
        if (node->left != nullptr) {
            node->left->parent = node;
        }
    } else if (key > node->key) {
        node->right = removeHelper(node->right, key, removed);
        if (node->right != nullptr) {
            node->right->parent = node;
        }
    } else {
        removed = true;
        treeSize--;
        
        // case 1: 
        if (node->left == nullptr) {
            AVLTreeNode<K, V>* temp = node->right;
            delete node;
            return temp;
        } else if (node->right == nullptr) {
            AVLTreeNode<K, V>* temp = node->left;
            delete node;
            return temp;
        }
        
        // case 2:
        AVLTreeNode<K, V>* temp = findMin(node->right);
        
        // copying the inorder successor's content to this node
        node->key = temp->key;
        node->value = temp->value;
        
        // deleting the inorder successor
        node->right = removeHelper(node->right, temp->key, removed);
        if (node->right != nullptr) {
            node->right->parent = node;
        }
    }
    
  
    return balance(node);
}

// in-order traversal to collect keys
template <typename K, typename V>
void AVLTree<K, V>::inOrderTraversal(AVLTreeNode<K, V>* node, std::vector<K>& keyList) const {
    if (node != nullptr) {
        inOrderTraversal(node->left, keyList);
        keyList.push_back(node->key);
        inOrderTraversal(node->right, keyList);
    }
}

// in-order traversal to collect values
template <typename K, typename V>
void AVLTree<K, V>::inOrderTraversalValues(AVLTreeNode<K, V>* node, std::vector<V>& valueList) const {
    if (node != nullptr) {
        inOrderTraversalValues(node->left, valueList);
        valueList.push_back(node->value);
        inOrderTraversalValues(node->right, valueList);
    }
}

// public methods
// insert method
template <typename K, typename V>
bool AVLTree<K, V>::insert(const K& key, const V& value) {
    bool inserted = false;
    root = insertHelper(root, key, value, inserted);
    return inserted;
}

// remove method
template <typename K, typename V>
bool AVLTree<K, V>::remove(const K& key) {
    bool removed = false;
    root = removeHelper(root, key, removed);
    return removed;
}

// search method
template <typename K, typename V>
V AVLTree<K, V>::search(const K& key) const {
    AVLTreeNode<K, V>* current = root;
    
    while (current != nullptr) {
        if (key < current->key) {
            current = current->left;
        } else if (key > current->key) {
            current = current->right;
        } else {
            // Key found
            return current->value;
        }
    }
    
    throw std::runtime_error("Key not found in the AVL tree");
}

// values method
template <typename K, typename V>
std::vector<V> AVLTree<K, V>::values() const {
    std::vector<V> valueList;
    inOrderTraversalValues(root, valueList);
    return valueList;
}

// keys method
template <typename K, typename V>
std::vector<K> AVLTree<K, V>::keys() const {
    std::vector<K> keyList;
    inOrderTraversal(root, keyList);
    return keyList;
}

// size method
template <typename K, typename V>
unsigned int AVLTree<K, V>::size() const {
    return treeSize;
}

#endif 