#ifndef A3_H
#define A3_H
#include <stdio.h>
#include <iostream>
#include <cmath>
using namespace std; 

/* Name: Shaunak Sachdev
Student Number: 301558905
Assignment Three
Course: CMPT 225 */ 


// Question 1

/* PARAM: arr: array to be "summed"
n: size of arr
result: pointer to array of size n*n
opCount: reference integer to track operations
POST: result is filled with the sum of each pair of elements from arr 
*/

void sumijBase(int arr[], int n, int* & result, int &opCount) {
    opCount = 0; // initializes the operation count

    result = new int[n * n]; 
    opCount++;

    int r = 0; 
    opCount++;

    while (r < n) { // r < n condition is checked about (n+1) times
        opCount++;

        int c = 0; 
        opCount++;

        while (c < n) { // the c < n condition checked (n+1) * n times
            opCount++;

            result[r * n + c] = arr[r] + arr[c]; 
            opCount++;

            c++; 
            opCount++;
        }
        r++; 
        opCount++;
    }
}


// Question 2


void trianglesBase(int n, int &opCount) {
    opCount = 0; // initializes the operation count

    int i = 0; 
    opCount++;

    // first triangle loop
    while (i < n) {
        opCount++; 

        int j = 0; 
        opCount++;

        while (j <= i) {
            opCount++; 

            cout << "*"; // printing a star
            opCount++;

            j++; 
            opCount++;
        }

        cout << endl; // printing newline
        opCount++;

        i++; 
        opCount++;
    }
    opCount++; // final false check for i < n

    // second square loop
    while (i > 0) {
        opCount++; 

        i--; 
        opCount++;

        int j = 0; 
        opCount++;

        while (j < i) {
            opCount++; 
            cout << "+"; // printing plus
            opCount++;

            j++; 
            opCount++;
        }

        while (j < n) {
            opCount++; 

            cout << "-"; // printing minus
            opCount++;

            j++; 
            opCount++;
        }

        cout << endl; // printing newline
        opCount++;
    }
    opCount++; 
}


// Question 3

// modified helper function: returns the smaller of the two integers
int minInt(int x, int y, int & opCount) {
    opCount++;  
    if (x < y)
        return x;
    else
        return y;
}

// modified helper function: returns the larger of the two integers
int maxInt(int x, int y, int & opCount) {
    opCount++;  
    if (x > y)
        return x;
    else
        return y;
}

// modified LCS function: returns the length of the longest common substring
// assumption: for worst-case analysis, let n = str1.size() = str2.size()
int LCS(string str1, string str2, int & opCount) {
    int n = str1.size(); opCount++;  
    int m = str2.size(); opCount++;  
    int maxLen = 0; opCount++;       
    
    int i = 0; opCount++;            
    while (i < n) {
        opCount++;  
        
        int j = 0; opCount++;        
        while (j < m) {
            opCount++;  
            
            int k = 0; opCount++;    
            // computing limits for the inner substring comparison
            int diff1 = n - i; opCount++;  
            int diff2 = m - j; opCount++;  
            int end = minInt(diff1, diff2, opCount); opCount++;  
            
            while (k < end) {
                opCount++;  
                
                opCount++;  
                if (str1.compare(i, k + 1, str2, j, k + 1) == 0) {
                    opCount++;  
                    
                    int tmp = k + 1; opCount++;  
                    maxLen = maxInt(maxLen, tmp, opCount); opCount++;  
                } else {
                    opCount++;  
                }
                k++; opCount++;  
            }
            opCount++;  
            
            j++; opCount++;  
        }
        opCount++;  
        
        i++; opCount++;  
    }
    opCount++;  
    
    return maxLen;  
}


// Question 4


// PARAM: arr is array from which duplicates are to be removed, n is size of arr
// POST: returns a vector containing arr without duplicates
void removeDuplicates(int arr[], int n, vector<int> &result, int &opCount) {
    opCount = 0;  
    int i = 0;  
    opCount++;

    while (i < n) {  // outer loop runs n times
        opCount++;  

        int iResult = 0;  
        opCount++;

        bool duplicate = false;  
        opCount++;

        // inner loop: checks if arr[i] exists in result
        while (iResult < (int)result.size() && !duplicate) {
            opCount++;  
            if (arr[i] == result[iResult]) {  
                opCount++;  

                duplicate = true;  
                opCount++;
            }
            iResult++;  
            opCount++;
        }
        opCount++;  

        if (!duplicate) {  
            opCount++;

            result.push_back(arr[i]);  
            opCount++;
        }

        i++;  
        opCount++;
    }
    opCount++;  
}


//Question 5

// PRE: initial call should pass 0 to i
// PARAM: arr is array to be sorted, n is size of array
// POST: arr is sorted in ascending order
void isort(int arr[], int n, int i, int &opCount)
{
    opCount++;  
    if (i < n) {
        opCount++;  

        
        int current = arr[i]; 
        opCount++;

        int pos = i - 1; 
        opCount++;

        
        while (pos >= 0 && arr[pos] > current) {
            opCount++;  
            
            arr[pos + 1] = arr[pos]; 
            opCount++;

            pos--; 
            opCount++;
        }
        opCount++;  
       
        arr[pos + 1] = current; 
        opCount++;

        
        isort(arr, n, i + 1, opCount);
    }
}

//Question 6

// PRE: n is an even number
// PARAM: n is the number to be repeatedly printed
// POST: prints a number square
void foo(int n, int &opCount)
{
    opCount = 0;  

    int limit = pow(2, n / 2); 

    int i = 0; 
    opCount++;

    while (i < limit) {  
        opCount++;

        int j = 0; 
        opCount++;

        while (j < limit) {  
            opCount++;

            cout << j + i * limit << " "; 
            opCount++;

            j++; 
            opCount++;
        }
        opCount++; 

        i++; 
        opCount++;

        cout << endl; 
        opCount++;
    }
    opCount++; 
}
#endif