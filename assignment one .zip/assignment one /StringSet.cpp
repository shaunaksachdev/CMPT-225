#include "StringSet.h"
#include <iostream>

// default constructor
StringSet::StringSet() : currentSize(0), maxSize(2) {
    array = new std::string[maxSize];
}

// copy constructor
StringSet::StringSet(const StringSet& other) : currentSize(other.currentSize), maxSize(other.maxSize) {
    array = new std::string[maxSize];
    for (int i = 0; i < currentSize; ++i) {
        array[i] = other.array[i];
    }
}

// destructor
StringSet::~StringSet() {
    delete[] array;
}

// overloaded assignment operator
StringSet& StringSet::operator=(const StringSet& other) {
    if (this == &other) {
        return *this; // to handle self-assignment
    }

    delete[] array;

    maxSize = other.maxSize;
    currentSize = other.currentSize;
    array = new std::string[maxSize];

    for (int i = 0; i < currentSize; ++i) {
        array[i] = other.array[i];
    }

    return *this;
}

// helper functions to resize the array
void StringSet::resize() {
    maxSize *= 2;
    std::string* newArray = new std::string[maxSize];

    for (int i = 0; i < currentSize; ++i) {
        newArray[i] = array[i];
    }

    delete[] array;
    array = newArray;
}

// insert method
bool StringSet::insert(const std::string& value) {
    if (find(value) != -1) {
        return false;
    }

    if (currentSize == maxSize) {
        resize();
    }

    array[currentSize++] = value;
    return true;
}

// remove method
bool StringSet::remove(const std::string& value) {
    int index = find(value);
    if (index == -1) {
        return false;
    }

    array[index] = array[currentSize - 1]; // to swap with the last element
    --currentSize;
    return true;
}

// find method
int StringSet::find(const std::string& value) const {
    for (int i = 0; i < currentSize; ++i) {
        if (array[i] == value) {
            return i;
        }
    }
    return -1;
}

// size method
int StringSet::size() const {
    return currentSize;
}

// ssUnion method
StringSet StringSet::ssUnion(const StringSet& other) const {
    StringSet result;

    // insert all elements from the calling object
    for (int i = 0; i < currentSize; ++i) {
        result.insert(array[i]);
    }

    // insert all elements from the other set
    for (int i = 0; i < other.currentSize; ++i) {
        result.insert(other.array[i]);
    }

    return result;
}

// intersection method
StringSet StringSet::intersection(const StringSet& other) const {
    StringSet result;

    // find common elements between this set and the other
    for (int i = 0; i < currentSize; ++i) {
        if (other.find(array[i]) != -1) {
            result.insert(array[i]);
        }
    }

    return result;
}

// difference method
StringSet StringSet::difference(const StringSet& other) const {
    StringSet result;

    // find elements that are in this set but not in the other
    for (int i = 0; i < currentSize; ++i) {
        if (other.find(array[i]) == -1) {
            result.insert(array[i]);
        }
    }

    return result;
}

/*The StringSet class is a custom implementation of a set that stores unique strings using a dynamic array. The default constructor initializes an empty set with a small array of size 2, while the copy constructor duplicates the contents of another StringSet. The destructor ensures proper memory management by deleting the dynamically allocated array when the object is destroyed. The overloaded assignment operator allows for the assignment of one StringSet to another, correctly managing memory by deleting the old array before copying over the new one.

The resize() function is used to double the array size when the set reaches its capacity. The insert() method adds a string to the set, ensuring no duplicates, and resizes the array if necessary. The remove() method removes a string by swapping it with the last element and reducing the size of the set. The find() method performs a linear search to locate a string in the set, returning its index or -1 if it’s not found. The size() method simply returns the current number of elements in the set.

The ssUnion() method returns the union of two sets by inserting all elements from both sets into a new StringSet. The intersection() method finds the common elements between two sets, while the difference() method returns a set of elements that are in the calling set but not in the other set. These set operations are implemented using simple loops and condition checks to ensure the correct results. The overall design provides basic set functionality with dynamic resizing and efficient element management.
*/