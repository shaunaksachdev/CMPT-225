#ifndef STRINGSET_H
#define STRINGSET_H

#include <string>

/* o-notation worst-case running times:

1. default constructor: o(1)  
   initializes a small dynamic array of size 2 and sets attributes. constant time.

2. copy constructor: o(n)  
   copies all elements from the source to the new array. scales linearly with the size of the source.

3. destructor: o(1)  
   frees the dynamic array memory. constant time.

4. overloaded assignment operator: o(n)  
   deallocates old memory, allocates new memory, and copies elements. linear with the size of the source array.

5. insert: o(n)  
   includes a linear search to check for duplicates (o(n)) and possible array resizing (o(n) for copying). overall linear.

6. remove: o(1)  
   swaps the target element with the last element and decrements the size. constant time.

7. find: o(n)  
   performs a linear search for the target string. worst-case requires checking all elements.

8. size: o(1)  
   simply returns the `currentsize` attribute. constant time.

9. ssunion: o(n + m)  
   combines the calling object (size n) and parameter (size m), ensuring no duplicates. scales with the total size.

10. intersection: o(n * m)  
    checks each element of the calling object against all elements of the parameter. quadratic time.

11. difference: o(n * m)  
    for each element in the calling object (size n), checks against the parameter (size m). quadratic time.
*/

class StringSet {
private:
    std::string* array; // dynamic array of strings
    int currentSize;    // number of elements currently stored
    int maxSize;        // maximum capacity of the array

    void resize();      // doubles the size of the array when full

public:
    // constructors and destructor
    StringSet();
    StringSet(const StringSet& other);
    ~StringSet();

    // overloaded assignment operator
    StringSet& operator=(const StringSet& other);

    // methods
    bool insert(const std::string& value);
    bool remove(const std::string& value);
    int find(const std::string& value) const;
    int size() const;

    StringSet ssUnion(const StringSet& other) const;
    StringSet intersection(const StringSet& other) const;
    StringSet difference(const StringSet& other) const;
};

#endif 