// Name: Shaunak Sachdev
// Student ID: 301558905

#ifndef QFUNCTIONS_H
#define QFUNCTIONS_H

#include "QueueT.h"
#include <stack>

// qconcatenate concatenates two queues into one queue
template <typename T>
QueueT<T> qconcatenate(QueueT<T> q1, QueueT<T> q2) {
    QueueT<T> result;
    
    // enqueues all elements from q1
    while (!q1.empty()) {
        result.enqueue(q1.dequeue());
    }

    // enqueues all elements from q2
    while (!q2.empty()) {
        result.enqueue(q2.dequeue());
    }

    return result;
}

// qmerge alternates elements from two queues into a new queue.
template <typename T>
QueueT<T> qmerge(QueueT<T> q1, QueueT<T> q2) {
    QueueT<T> result;
    
    // merges elements alternatively
    while (!q1.empty() || !q2.empty()) {
        if (!q1.empty()) {
            result.enqueue(q1.dequeue());
        }
        if (!q2.empty()) {
            result.enqueue(q2.dequeue());
        }
    }

    return result;
}

// qreverse reverses the contents of a queue using an STL stack.
template <typename T>
QueueT<T> qreverse(QueueT<T> q) {
    QueueT<T> result;
    std::stack<T> tempStack;
    
    // pushes all elements onto the stack
    while (!q.empty()) {
        tempStack.push(q.dequeue());
    }

    // pops elements from stack and enqueue them to result the queue
    while (!tempStack.empty()) {
        result.enqueue(tempStack.top());
        tempStack.pop();
    }

    return result;
}

#endif 