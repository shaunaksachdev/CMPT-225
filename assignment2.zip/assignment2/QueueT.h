// Name: Shaunak Sachdev
// Student ID: 301558905

#ifndef QUEUET_H
#define QUEUET_H

#include <iostream>
#include <stdexcept>

/*
 * implementation of a template based queue data structure using a singly linked list
 * the queue maintains both front and back pointers for efficient operations
 * all operations are implemented to run in constant time whereever possible
 */

// NodeT represents a single node in our linked queue structure
// each node holds the actual data and a pointer to the next node
template <typename T>
class NodeT {
public:
    T data;
    NodeT<T>* next;

    NodeT(const T& value, NodeT<T>* nextNode = nullptr) : data(value), next(nextNode) {}
};

// QueueT class template
template <typename T>
class QueueT {
private:
    NodeT<T>* front;
    NodeT<T>* back;
    int queueSize;

    void copyQueue(const QueueT<T>& other);
    void clearQueue();

public:
    QueueT();
    QueueT(const QueueT<T>& other);
    ~QueueT();
    QueueT<T>& operator=(const QueueT<T>& other);
    
    void enqueue(const T& value);
    T dequeue();
    bool empty() const;
    int size() const;
    
    template <typename U>
    friend std::ostream& operator<<(std::ostream& os, const QueueT<U>& queue);
};

// implementation of all the QueueT methods

// default constructor
template <typename T>
QueueT<T>::QueueT() : front(nullptr), back(nullptr), queueSize(0) {}

// copy constructor
template <typename T>
QueueT<T>::QueueT(const QueueT<T>& other) : front(nullptr), back(nullptr), queueSize(0) {
    copyQueue(other);
}

// destructor
template <typename T>
QueueT<T>::~QueueT() {
    clearQueue();
}

// assignment operator
template <typename T>
QueueT<T>& QueueT<T>::operator=(const QueueT<T>& other) {
    if (this != &other) {
        clearQueue();
        copyQueue(other);
    }
    return *this;
}

// enqueue method
template <typename T>
void QueueT<T>::enqueue(const T& value) {
    NodeT<T>* newNode = new NodeT<T>(value);
    if (empty()) {
        front = back = newNode;
    } else {
        back->next = newNode;
        back = newNode;
    }
    queueSize++;
}

// dequeue method
template <typename T>
T QueueT<T>::dequeue() {
    if (empty()) {
        throw std::runtime_error("Queue is empty");
    }
    NodeT<T>* temp = front;
    T value = temp->data;
    front = front->next;
    delete temp;
    queueSize--;
    if (queueSize == 0) {
        back = nullptr;
    }
    return value;
}

// empty method
template <typename T>
bool QueueT<T>::empty() const {
    return queueSize == 0;
}

// size method
template <typename T>
int QueueT<T>::size() const {
    return queueSize;
}

// copy queue helper function
template <typename T>
void QueueT<T>::copyQueue(const QueueT<T>& other) {
    NodeT<T>* current = other.front;
    while (current) {
        enqueue(current->data);
        current = current->next;
    }
}

// clear queue 
template <typename T>
void QueueT<T>::clearQueue() {
    while (front != nullptr) {
        NodeT<T>* temp = front;
        front = front->next;
        delete temp;
    }
    back = nullptr;
    queueSize = 0;
}

// overloaded output operator
template <typename T>
std::ostream& operator<<(std::ostream& os, const QueueT<T>& queue) {
    os << "{";
    NodeT<T>* current = queue.front;
    while (current) {
        os << current->data;
        if (current->next) {
            os << ",";
        }
        current = current->next;
    }
    os << "}";
    return os;
}

#endif