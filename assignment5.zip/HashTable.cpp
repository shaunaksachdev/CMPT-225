#include "HashTable.h"
#include <cmath>
#include <iostream>
#include <algorithm>

// default constructor
HashTable::HashTable() : tableSize(101), itemCount(0) {
    table = new string[tableSize];
    p2 = findNextPrime(tableSize / 2); // used for second hash
}

// constructor with expected number of items
HashTable::HashTable(int n) : itemCount(0) {
    tableSize = findNextPrime(2 * n); // double the size and make it prime
    table = new string[tableSize];
    p2 = findNextPrime(tableSize / 2);
}

// copy constructor
HashTable::HashTable(const HashTable& other) {
    tableSize = other.tableSize;
    itemCount = other.itemCount;
    p2 = other.p2;
    table = new string[tableSize];
    for (int i = 0; i < tableSize; ++i)
        table[i] = other.table[i];
}

// destructor
HashTable::~HashTable() {
    delete[] table;
}

// assignment operator: deep copies data from another hashtable
HashTable& HashTable::operator=(const HashTable& other) {
    if (this != &other) {
        delete[] table;
        tableSize = other.tableSize;
        itemCount = other.itemCount;
        p2 = other.p2;
        table = new string[tableSize];
        for (int i = 0; i < tableSize; ++i)
            table[i] = other.table[i];
    }
    return *this;
}

// generates a numeric value for a string using horner’s method
int HashTable::getStringValue(const string& word) const {
    long long value = 0;
    for (char ch : word) {
        value = (value * 33 + (ch - 'a' + 1)) % tableSize;
    }
    return static_cast<int>(value);
}

// first hash function
int HashTable::hash(const string& word) const {
    return getStringValue(word) % tableSize;
}

// second hash function (used for double hashing)
int HashTable::secondHash(const string& word) const {
    int strVal = getStringValue(word);
    return p2 - (strVal % p2);
}

// checks if a word exists in the table
bool HashTable::find(const string& word) const {
    int index = hash(word);
    int step = secondHash(word);
    int startIndex = index;

    while (!table[index].empty()) {
        if (table[index] == word) return true;
        index = (index + step) % tableSize;
        if (index == startIndex) break; // full cycle, stop
    }
    return false;
}

// inserts a word into the hash table
void HashTable::insert(const string& word) {
    if (find(word)) return; // no duplicates

    int index = hash(word);
    int step = secondHash(word);

    while (!table[index].empty()) {
        index = (index + step) % tableSize;
    }
    table[index] = word;
    ++itemCount;

    // check load factor and rehash if needed
    if (loadFactor() > 0.67) {
        rehash();
    }
}

// returns number of items in the table
int HashTable::size() const {
    return itemCount;
}

// returns max capacity of table
int HashTable::maxSize() const {
    return tableSize;
}

// returns current load factor
double HashTable::loadFactor() const {
    return static_cast<double>(itemCount) / tableSize;
}

// helper to check if a number is prime
static bool isPrime(int num) {
    if (num <= 1) return false;
    if (num == 2) return true;
    if (num % 2 == 0) return false;
    for (int i = 3; i * i <= num; i += 2) {
        if (num % i == 0) return false;
    }
    return true;
}

// finds the next prime number >= given number
int HashTable::findNextPrime(int num) const {
    while (!isPrime(num)) ++num;
    return num;
}

// doubles the table size and reinserts existing items
void HashTable::rehash() {
    int oldSize = tableSize;
    string* oldTable = table;

    tableSize = findNextPrime(2 * oldSize);
    p2 = findNextPrime(tableSize / 2);
    table = new string[tableSize];
    itemCount = 0;

    for (int i = 0; i < oldSize; ++i) {
        if (!oldTable[i].empty()) {
            insert(oldTable[i]); // reinsert into new table
        }
    }

    delete[] oldTable;
}
