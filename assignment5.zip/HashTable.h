#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <string>
using namespace std;

class HashTable {
public:
    HashTable();
    HashTable(int n);
    HashTable(const HashTable& other);
    ~HashTable();
    HashTable& operator=(const HashTable& other);

    void insert(const string& word);
    bool find(const string& word) const;
    int size() const;
    int maxSize() const;
    double loadFactor() const;

private:
    string* table;
    int tableSize;
    int p2;
    int itemCount;

    int hash(const string& word) const;
    int secondHash(const string& word) const;
    int getStringValue(const string& word) const;
    int findNextPrime(int num) const;
    void rehash();
};

#endif
 