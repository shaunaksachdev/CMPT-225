#ifndef SPELLCHECK_H
#define SPELLCHECK_H

#include "HashTable.h"
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

vector<string> extraLetter(const HashTable& dict, string word) {
    if (dict.find(word)) return {word};
    vector<string> result;
    for (size_t i = 0; i < word.size(); ++i) {
        string candidate = word.substr(0, i) + word.substr(i + 1);
        if (dict.find(candidate)) result.push_back(candidate);
    }
    sort(result.begin(), result.end());
    return result;
}

vector<string> transposition(const HashTable& dict, string word) {
    if (dict.find(word)) return {word};
    vector<string> result;
    for (size_t i = 0; i < word.size() - 1; ++i) {
        string candidate = word;
        swap(candidate[i], candidate[i + 1]);
        if (dict.find(candidate)) result.push_back(candidate);
    }
    sort(result.begin(), result.end());
    return result;
}

vector<string> missingSpace(const HashTable& dict, string word) {
    if (dict.find(word)) return {word};
    vector<string> result;
    for (size_t i = 1; i < word.size(); ++i) {
        string left = word.substr(0, i);
        string right = word.substr(i);
        if (dict.find(left) && dict.find(right)) {
            result.push_back(left + " " + right);
        }
    }
    sort(result.begin(), result.end());
    return result;
}

vector<string> missingLetter(const HashTable& dict, string word) {
    if (dict.find(word)) return {word};
    vector<string> result;
    for (size_t i = 0; i <= word.size(); ++i) {
        for (char c = 'a'; c <= 'z'; ++c) {
            string candidate = word.substr(0, i) + c + word.substr(i);
            if (dict.find(candidate)) result.push_back(candidate);
        }
    }
    sort(result.begin(), result.end());
    return result;
}

vector<string> incorrectLetter(const HashTable& dict, string word) {
    if (dict.find(word)) return {word};
    vector<string> result;
    for (size_t i = 0; i < word.size(); ++i) {
        char original = word[i];
        for (char c = 'a'; c <= 'z'; ++c) {
            if (c == original) continue;
            string candidate = word;
            candidate[i] = c;
            if (dict.find(candidate)) result.push_back(candidate);
        }
    }
    sort(result.begin(), result.end());
    return result;
}
#endif